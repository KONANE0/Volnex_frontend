const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let rocketImg = new Image();
rocketImg.src = "assets/rocket.png";

let coinImg = new Image();
coinImg.src = "assets/coin.png";

let planetImgs = [];
for (let i = 1; i <= 10; i++) {
  let img = new Image();
  img.src = `assets/planet${i}.png`;
  planetImgs.push(img);
}

let rocket = {
  x: canvas.width / 2 - 25,
  y: canvas.height - 80,
  width: 50,
  height: 50,
  speed: 6,
};

let coins = [];
let planets = [];
let score = 0;
let hits = 0;
let difficulty = 1;
let frameCount = 0;

function drawRocket() {
  ctx.drawImage(rocketImg, rocket.x, rocket.y, rocket.width, rocket.height);
}

function drawItems() {
  coins.forEach((coin) => {
    ctx.drawImage(coinImg, coin.x, coin.y, coin.size, coin.size);
  });

  planets.forEach((planet) => {
    ctx.drawImage(planetImgs[planet.imgIndex], planet.x, planet.y, planet.size, planet.size);
  });
}

function moveItems() {
  coins.forEach((coin) => {
    coin.y += coin.speed;
  });
  planets.forEach((planet) => {
    planet.y += planet.speed;
  });
}

function detectCollisions() {
  coins = coins.filter((coin) => {
    if (
      coin.x < rocket.x + rocket.width &&
      coin.x + coin.size > rocket.x &&
      coin.y < rocket.y + rocket.height &&
      coin.y + coin.size > rocket.y
    ) {
      score += 50;
      updateScore();
      return false;
    }
    return true;
  });

  planets = planets.filter((planet) => {
    if (
      planet.x < rocket.x + rocket.width &&
      planet.x + planet.size > rocket.x &&
      planet.y < rocket.y + rocket.height &&
      planet.y + planet.size > rocket.y
    ) {
      hits++;
      if (hits === 1) {
        score = Math.floor(score / 2);
        flashScore();
        updateScore();
        return false;
      } else {
        endGame();
        return false;
      }
    }
    return true;
  });
}

function updateScore() {
  document.getElementById("score").textContent = score;
}

function flashScore() {
  const el = document.getElementById("score");
  el.style.color = "red";
  setTimeout(() => (el.style.color = "white"), 300);
}

function endGame() {
  cancelAnimationFrame(animationId);
  document.body.innerHTML += `
    <div class="game-over">
      <h2>انتهت اللعبة</h2>
      <p>نقاطك: ${score}</p>
      <button onclick="location.reload()">اللعب مرة أخرى</button>
      <button onclick="location.href='home.html'">العودة للرئيسية</button>
    </div>
  `;
}

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRocket();
  drawItems();
  moveItems();
  detectCollisions();

  if (frameCount % 60 === 0) {
    spawnItems();
    if (difficulty < 7) difficulty += 0.05;
  }

  frameCount++;
  animationId = requestAnimationFrame(gameLoop);
}

function spawnItems() {
  const coinCount = Math.floor(Math.random() * 3) + 1;
  const planetCount = Math.random() < 0.5 ? 1 : 0;

  for (let i = 0; i < coinCount; i++) {
    coins.push({
      x: Math.random() * (canvas.width - 30),
      y: -30,
      size: 30,
      speed: 2 + difficulty,
    });
  }

  for (let i = 0; i < planetCount; i++) {
    planets.push({
      x: Math.random() * (canvas.width - 40),
      y: -40,
      size: 40,
      speed: 2 + difficulty,
      imgIndex: Math.floor(Math.random() * planetImgs.length),
    });
  }
}

canvas.addEventListener("touchstart", (e) => {
  const touchX = e.touches[0].clientX;
  if (touchX < canvas.width / 2) {
    rocket.x -= rocket.speed * 2;
  } else {
    rocket.x += rocket.speed * 2;
  }
});

let animationId = requestAnimationFrame(gameLoop);
